//
//  MyView.h
//  DragMeToHell
//
//  Created by Robert Irwin on 2/18/12.
//  Copyright (c) 2012 Robert J. Irwin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView <UIAlertViewDelegate>
{
    UIAlertView *alertViewForLost;
    UIAlertView *alertViewForWon;
}

@property (nonatomic, assign) CGFloat dw, dh;  // width and height of cell
@property (nonatomic, assign) CGFloat x, y;    // touch point coordinates
@property (nonatomic, assign) int row, col;    // selected cell in cell grid
@property (nonatomic, assign) BOOL inMotion;   // YES iff in process of dragging
@property (nonatomic, strong) NSString *s;     // item to drag around grid
@property (nonatomic, assign) int firstRun;
@property (nonatomic, strong) NSMutableArray* xValues;
@property (nonatomic, strong) NSMutableArray* yValues;
@property (nonatomic, assign) int clashCount;
@property (nonatomic, assign) int previousMatchX;
@property (nonatomic, assign) int previousMatchY;

@end

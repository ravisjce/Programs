//
//  MyView.m
//  DragMeToHell
//
//  Created by Robert Irwin on 2/18/12.
//  Copyright (c) 2012 Robert J. Irwin. All rights reserved.
//

#import "MyView.h"

@implementation MyView

@synthesize dw, dh, row, col, x, y, inMotion, s, firstRun, xValues, yValues, clashCount, previousMatchX, previousMatchY;

- (id)initWithFrame:(CGRect)frame {
    NSLog( @"initWithFrame:" );
   return self = [super initWithFrame:frame];
}

- (void)awakeFromNib
{
    NSLog(@"awakefromnib called");
    xValues = [[NSMutableArray alloc] initWithCapacity:20];
    yValues = [[NSMutableArray alloc] initWithCapacity:20];
    alertViewForLost = [[UIAlertView alloc] initWithTitle:@"Game Lost"
                                                   message:@"You Lost the Game !!!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alertViewForWon = [[UIAlertView alloc] initWithTitle:@"Victory!!!"
                                                  message:@"You Won the Game !!!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
}

- (void)drawRect:(CGRect)rect
{
    //NSLog( @"drawRect:" );

    
    CGContextRef context = UIGraphicsGetCurrentContext();  // obtain graphics context
    // CGContextScaleCTM( context, 0.5, 0.5 );  // shrink into upper left quadrant
    CGRect bounds = [self bounds];          // get view's location and size
    CGFloat w = CGRectGetWidth( bounds );   // w = width of view (in points)
    CGFloat h = CGRectGetHeight ( bounds ); // h = height of view (in points)
    int currentXCoordinate = 0;
    int currentYCoordinate = 0;
  
    dw = w/10.0f;                           // dw = width of cell (in points)
    dh = h/10.0f;                           // dh = height of cell (in points)
    
   // NSLog( @"view (width,height) = (%g,%g)", w, h );
   // NSLog( @"cell (width,height) = (%g,%g)", dw, dh );
   // NSLog(@"first run value is %d",firstRun);
    
    // draw lines to form a 10x10 cell grid
    CGContextBeginPath( context );               // begin collecting drawing operations
    for ( int i = 1;  i < 10;  ++i ) 
    {
        // draw horizontal grid line
        CGContextMoveToPoint( context, 0, i*dh );
        CGContextAddLineToPoint( context, w, i*dh );
        
    }
    for ( int i = 1;  i < 10;  ++i ) 
    {
        // draw vertical grid line
        CGContextMoveToPoint( context, i*dw, 0 );
        CGContextAddLineToPoint( context, i*dw, h );
    }
    [[UIColor grayColor] setStroke];             // use gray as stroke color
    CGContextDrawPath( context, kCGPathStroke ); // execute collected drawing ops
    
    // establish bounding box for image
    CGPoint tl = self.inMotion ? CGPointMake( x, y )     
                               : CGPointMake( row*dw, col*dh );
    
    if (firstRun == 0)
    {
        firstRun++;
        tl.x = 0;
        tl.y = 0;
        
        for (int i=0; i<20; i++)
        {
            
                currentXCoordinate = arc4random_uniform(10);
                currentYCoordinate = arc4random_uniform(10);
                
                while ((currentXCoordinate==0 && currentYCoordinate==0) || (currentXCoordinate==9 && currentYCoordinate==9))
                {
                    currentXCoordinate = arc4random_uniform(10);
                    currentYCoordinate = arc4random_uniform(10);
                }
            
            /*
                while ( [xValues containsObject:[NSNumber numberWithInt:currentXCoordinate]])
                {
                    NSInteger indexOfXCoordinate = [xValues indexOfObject:[NSNumber numberWithInt:currentXCoordinate]];
                    NSLog(@"match found");
                    if (currentYCoordinate == [[yValues objectAtIndex:indexOfXCoordinate] integerValue])
                    {
                        currentXCoordinate = arc4random_uniform(10);
                        currentYCoordinate = arc4random_uniform(10);
                    }
                }
            */
            [xValues addObject: [NSNumber numberWithInt: currentXCoordinate]];
            [yValues addObject: [NSNumber numberWithInt: currentYCoordinate]];
            
            CGRect imageRect = CGRectMake([[xValues objectAtIndex:i] intValue]*dw, [[yValues objectAtIndex:i] intValue]*dh, dw, dh);
            
            UIImage *img;
            img = [UIImage imageNamed:@"devil"];
            [img drawInRect:imageRect];
        }
    }
    
    else{
        for (int i=0; i<20; i++) {
            UIImage *img;
            
            currentXCoordinate = [[xValues objectAtIndex:i] intValue];
            currentYCoordinate = [[yValues objectAtIndex:i] intValue];
           int touchRow = self.x/self.dw;
            int touchColumn = self.y/self.dh;
            NSLog(@"self x and y are %d %d",touchRow,touchColumn);
            NSLog(@"current x and y coordinates are %d %d",currentXCoordinate,currentYCoordinate);
            
            if (currentXCoordinate == touchRow && currentYCoordinate == touchColumn)
            {
              //  NSLog(@"found the match");
                
                if (touchRow!=previousMatchX || touchColumn!=previousMatchY)
                {
                    if (clashCount == 3)
                    {
                        [alertViewForLost show];
                        return;
                    }
                    clashCount++;
                    previousMatchX = touchRow;
                    previousMatchY = touchColumn;
                }
                CGRect imageRect = CGRectMake(currentXCoordinate*dw, currentYCoordinate*dh, dw*2, dh*2);
                img = [UIImage imageNamed:@"devil"];
                [img drawInRect:imageRect];
            }
            
            else
            {
               // NSLog(@"no match found");
                CGRect imageRect = CGRectMake(currentXCoordinate*dw, currentYCoordinate*dh, dw, dh);
                img = [UIImage imageNamed:@"devil"];
                [img drawInRect:imageRect];
            }
            
        }
        
    }
    
    NSLog(@"t1 x and y values are %f %f",tl.x,tl.y);
    NSLog(@"clash count value is %d",clashCount);
        CGRect imageRect = CGRectMake(tl.x, tl.y, dw/pow(2, clashCount), dh/pow(2, clashCount));
        
        // place appropriate image where dragging stopped
        UIImage *img;
        if ( self.row == 9  &&  self.col == 9 )
            img = [UIImage imageNamed:@"devil"];
        else
            img = [UIImage imageNamed:@"angel"];
        [img drawInRect:imageRect];
    
}


-(void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event
{
    int touchRow, touchCol;
    CGPoint xy;
    
   // NSLog( @"touchesBegan:withEvent:" );
    [super touchesBegan: touches withEvent: event];
    for ( id t in touches )
    {
        xy = [t locationInView: self];
        self.x = xy.x;  self.y = xy.y;
        touchRow = self.x / self.dw;
        touchCol = self.y / self.dh;
        self.inMotion = (self.row == touchRow  &&  self.col == touchCol);
       // NSLog( @"touch point (x,y) = (%g,%g)", self.x, self.y );
      //  NSLog( @"  falls in cell (row,col) = (%d,%d)", touchRow, touchCol );
    }
}


-(void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event
{    
    int touchRow, touchCol;
    CGPoint xy;

   // NSLog( @"touchesMoved:withEvent:" );
    [super touchesMoved: touches withEvent: event];
    
    for ( id t in touches )
    {
        xy = [t locationInView: self];
        self.x = xy.x;  self.y = xy.y;
        touchRow = self.x / self.dw;  touchCol = self.y / self.dh;
      //  NSLog( @"touch point (x,y) = (%g,%g)", self.x, self.y );
       // NSLog( @"  falls in cell (row,col) = (%d,%d)", touchRow, touchCol );
    }
    if ( self.inMotion )
        [self setNeedsDisplay];            
}


-(void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event
{    
    NSLog( @"touchesEnded:withEvent:" );
    [super touchesEnded: touches withEvent: event];
    if ( self.inMotion )
    {
        int touchRow = 0, touchCol = 0;
        CGPoint xy ;
        
        for ( id t in touches )
        {
            xy = [t locationInView: self];
            self.x = xy.x;  self.y = xy.y;
            touchRow = self.x / self.dw;  touchCol = self.y / self.dh;
           // NSLog( @"touch point (x,y) = (%g,%g)", x, y );
          //  NSLog( @"  falls in cell (row,col) = (%d,%d)", touchRow, touchCol );
        }
        self.inMotion = NO;
        self.row = touchRow;  self.col = touchCol;
        if ( self.row == 9  &&  self.col == 9 )
        {
            [self setBackgroundColor: [UIColor redColor]];
            [alertViewForWon show];
            return;
            
        }
        else
            [self setBackgroundColor: [UIColor cyanColor]];
            
        [self setNeedsDisplay];
    }
}


-(void) touchesCancelled: (NSSet *) touches withEvent: (UIEvent *) event
{
    NSLog( @"touchesCancelled:withEvent:" );
    
    [super touchesCancelled: touches withEvent: event];    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"alertview called");
    
    if (alertView == alertViewForWon)
    {
        [self setBackgroundColor: [UIColor cyanColor]];
    }
    
    previousMatchX = 0;
    previousMatchY = 0;
    clashCount = 0;
    firstRun = 0;
    self.row = 0;
    self.col = 0;
    [self setNeedsDisplay];
}
@end
